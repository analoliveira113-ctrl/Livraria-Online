const http = require('http'); //importa o módulo nativo "http"
const colors = require('colors'); //importa o módulo colors
const fs = require('fs'); //importa módulo File System para ler arquivos
const path = require ('path'); //importa módulo para "caminho" e (rotas se for express)

//simular dados de um banco de dados
const livros = [
    {id: 1, livros: "Em decomposição", valor: 59.90},
    {id: 2, livros: "A paciente silenciosa", valor: 49.90},
    {id: 3, livros: "Um trono para irmãs", valor: 63.90},
    {id: 4, livros: "A empregada", valor: 53.31},
    {id: 5, livros: "Melhor do que nos filmes", valor: 43.01},
    {id: 6, livros: "Bridgerton: O duque e eu", valor: 47.40},
]; 

//criar o servidor
//função callback que receb a requisição (req) e a resposta (res)
//req (Request): informações sobre pedido do usuário.
//res (Response): objeto para enviar a resposta de volta ao usuário
const server = http.createServer ((req, res) => {

    //log para ver qual URL está sendo acessada no terminal
console.log(`Requisição recebida: ${req.url}`.green);

    // roteamento simple (caminho da URL)
    if (req.url === '/livros') {
        //lê o arquivo 'index.html' que está na pasta public
        const filePath = path.join(__dirname, 'public', 'index.html');

        fs.readFile(filePath, 'utf8', (err, content) => {
            if (err) {
                res.writeHead(500);
                res.end('Erro do servidor');
            } else {
                res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'});
                res.end(content);
            }
        });
    }
    //rota da API retornando a tabela em formato JSON
    // localhost:3000/api/livros que pode ser consomida (mostrada) no front-end
    else if (req.url === '/api/livros'){
        res.writeHead(200, {'Content-Type': 'application/json; charset=utf-8'});
        res.end(JSON.stringify(livros));
    }

    else{
      
        //lê o arquivo '404.html' que está na pasta public
        const path404 = path.join(__dirname, 'public', '404.html');
        fs.readFile(path404, 'utf8', (err, content) => {
            if (err) {
                res.writeHead(404, {'Content-Type': 'text/plain; charset=utf-8'});
                res.end('Página não encontrada (404)');
            } else {
                res.writeHead(404, {'Content-Type': 'text/html; charset=utf-8'});
                res.end(content);
            }
        });
    


    }
});

//configurar a porta do servidor
const PORT = 3000;

//iniciar o servidor, usar o listen para ouvir a porta
server.listen(PORT, () =>{
    console.log(`Servidor rodando http://localhost:${PORT}`.green.bold);
});
